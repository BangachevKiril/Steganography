import unittest

import torch

from stego.smoke import _tensor_bytes, sample_indices


class SmokeUtilityTests(unittest.TestCase):
    def test_large_tensor_indices_never_round_past_the_end(self):
        # Test dimensions, without allocating these potentially huge tensors.
        for length in (2**24 + 1, 2**28, 151936 * 2560, 2**31 + 17, 2**53 + 7):
            with self.subTest(length=length):
                indices = sample_indices(length)
                self.assertEqual(len(indices), 32)
                self.assertEqual(indices[0], 0)
                self.assertEqual(indices[-1], length - 1)
                self.assertTrue(all(0 <= i < length for i in indices))
                self.assertEqual(indices, sorted(set(indices)))
        # The original float32 endpoint calculation reproduces the failure.
        self.assertEqual(torch.linspace(0, 2**28 - 1, 32)[-1].long().item(), 2**28)

    def test_small_and_empty_tensors(self):
        self.assertEqual(sample_indices(0), [])
        self.assertEqual(sample_indices(1), [0])
        self.assertEqual(sample_indices(4), [0, 1, 2, 3])
        self.assertEqual(sample_indices(100, 1), [0])
        with self.assertRaises(ValueError):
            sample_indices(-1)

    def test_scalar_and_bfloat16_hash_bytes(self):
        self.assertEqual(len(_tensor_bytes(torch.tensor(1.0))), 4)
        self.assertEqual(len(_tensor_bytes(torch.tensor([1, 2], dtype=torch.bfloat16))), 4)


if __name__ == "__main__":
    unittest.main()
