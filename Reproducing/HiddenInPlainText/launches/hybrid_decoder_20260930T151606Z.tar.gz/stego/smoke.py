"""Isolated GPU canary: never reuse these synthetic-reward adapters for training.

Run ``python -m stego.smoke --config CONFIG --output REPORT`` before launching
the real trainer in a fresh process.  This script does not submit Slurm jobs.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import tempfile
import time
from typing import Any


def _tensor_bytes(value: Any) -> bytes:
    import torch
    return value.detach().reshape(-1).contiguous().cpu().view(torch.uint8).numpy().tobytes()


def sample_indices(length: int, maximum: int = 32) -> list[int]:
    """Spread indices using integers; float32 rounds large tensor endpoints up."""
    if length < 0 or maximum < 1:
        raise ValueError("Expected nonnegative length and positive sample count")
    count = min(length, maximum)
    if count < 2:
        return [0] if count else []
    return [i * (length - 1) // (count - 1) for i in range(count)]


def adapter_digest(engine: Any, agent: str) -> str:
    digest = hashlib.sha256()
    for parameter in engine.adapter_parameters[agent]:
        digest.update(_tensor_bytes(parameter))
    return digest.hexdigest()


def frozen_fingerprint(model: Any, *, exclude_adapters: bool = False) -> dict[str, Any]:
    """Every mutation counter plus samples spread across every frozen tensor."""
    import torch
    digest = hashlib.sha256()
    versions = {}
    for name, parameter in model.named_parameters():
        if exclude_adapters and "lora_" in name:
            continue
        versions[name] = parameter._version
        flat = parameter.detach().reshape(-1)
        indices = torch.tensor(sample_indices(flat.numel()), dtype=torch.long,
                               device=flat.device)
        digest.update(name.encode())
        digest.update(_tensor_bytes(flat[indices]))
    return {"parameter_versions": versions, "sampled_sha256": digest.hexdigest()}


def optimizer_digest(optimizer: Any) -> str:
    import torch
    digest = hashlib.sha256()

    def visit(value):
        if isinstance(value, torch.Tensor):
            digest.update(str((str(value.dtype), tuple(value.shape))).encode())
            digest.update(_tensor_bytes(value.reshape(-1)))
        elif isinstance(value, dict):
            for key in sorted(value, key=str):
                digest.update(repr(key).encode())
                visit(value[key])
        elif isinstance(value, (tuple, list)):
            for item in value:
                visit(item)
        else:
            digest.update(repr(value).encode())

    visit(optimizer.state_dict())
    return digest.hexdigest()


def assert_probability_consistency(engine: Any, agent: str, trajectories: list[Any]) -> dict[str, float]:
    import torch
    engine._activate(agent, train=False)
    differences = []
    with torch.inference_mode():
        for trajectory in trajectories:
            actual = engine._trajectory_logps(trajectory)
            old = torch.tensor([p for p, flag in zip(trajectory.old_logps, trajectory.action_mask)
                                if flag], device=actual.device)
            differences.extend((actual - old).abs().tolist())
    absolute = torch.tensor(differences)
    if not len(differences) or not torch.isfinite(absolute).all():
        raise AssertionError("Missing or nonfinite behavior probabilities")
    mean, maximum = absolute.mean().item(), absolute.max().item()
    # Cached batched and uncached singleton BF16 matrix products need not round
    # identically.  CPU exact-distribution tests use a much tighter 1e-6 bound.
    if mean > 0.08 or maximum > 0.6:
        raise AssertionError(f"Cached/full-forward probability mismatch: mean={mean}, max={maximum}")
    return {"mean_absolute_logprob_difference": mean,
            "max_absolute_logprob_difference": maximum,
            "p99_absolute_logprob_difference": torch.quantile(absolute, 0.99).item(),
            "action_tokens_compared": len(differences)}


def run(config: dict[str, Any]) -> dict[str, Any]:
    import torch
    from .engine import Engine

    if not torch.cuda.is_available():
        raise RuntimeError("This canary requires a CUDA GPU")
    seed = int(config.get("seed", 20260928)) + 1729
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    cfg = dict(config)
    cfg.update(think_tokens=32, answer_tokens=48, final_answer_tokens=48,
               generation_batch_size=4, train_microbatch_size=1)
    started = time.monotonic()
    engine = Engine(cfg["communicator_path"], cfg["judge_path"], cfg)
    base_before = frozen_fingerprint(engine.model, exclude_adapters=True)
    judge_before = frozen_fingerprint(engine.judge)
    adapter_before = {agent: adapter_digest(engine, agent) for agent in engine.AGENTS}
    print(json.dumps({"smoke_stage": "models_loaded", "seconds": time.monotonic() - started}), flush=True)

    short = [{"role": "system", "content": "Think briefly, then give your decision."},
             {"role": "user", "content": "The hidden bit is either 0 or 1. Make a guess."}]
    long = [{"role": "system", "content": "Privately reason about a hidden-bit communication problem before deciding."},
            {"role": "user", "content": (
                "Question: How should a person carry fragile groceries home? "
                "Sender's answer: Put heavy containers on the bottom and keep fragile items on top. "
                "Carry the bag upright and set it down carefully. "
                "The sender was asked to communicate either bit 0 or bit 1, but its convention is unknown. "
                "Consider possible word-choice and sentence-structure conventions, then guess the bit.") }]
    ragged = engine.generate("A", [short, long, short, long], kind="bit", seed=seed + 1)
    assert len({len(t.prompt_ids) for t in ragged}) == 2
    assert all(t.final_text in ("0", "1") and t.thought_token_count <= 32 for t in ragged)
    consistency = assert_probability_consistency(engine, "A", ragged)
    print(json.dumps({"smoke_stage": "ragged_probabilities", **consistency,
                      "thought_lengths": [t.thought_token_count for t in ragged]}), flush=True)

    sender_messages = [{"role": "system", "content": (
        "Answer the question in 2–4 complete sentences. You may think privately first.")},
        {"role": "user", "content": "How can I keep a paper shopping bag from tearing when it rains?"}]
    sender = engine.generate("A", [sender_messages], kind="sender", seed=seed + 2)[0]
    assert sender.thought_token_count <= 32 and sender.final_token_count <= 48
    assert sender.final_text
    sender_consistency = assert_probability_consistency(engine, "A", [sender])

    # Validate optimizer plumbing in a separate, discarded process. The hybrid
    # regression deliberately uses an all-wrong group that centered GRPO stalls on.
    group = engine.generate("A", [long] * 8, kind="bit", seed=seed + 3)
    hybrid = cfg.get('decoder_objective') == 'fixed_baseline_pg_ce'
    if hybrid:
        group = [group[0]] * 8
        target_bit = 1 - int(group[0].final_text)
        metrics = engine.update("A", [group], [[0.0] * 8], target_bits=[target_bit])
        assert metrics['decoder_ce'] > 0
        assert metrics['reasoning_pg_active_fraction'] == 1
        assert metrics['decoder_counterfactual_grpo_active_group_fraction'] == 0
    else:
        metrics = engine.update("A", [group], [[0, 0, 0, 0, 1, 1, 1, 1]])
    if metrics["grad_norm"] <= 0 or not all(torch.isfinite(torch.tensor(x)).item() for x in metrics.values()):
        raise AssertionError(f"Expected finite, nonzero update: {metrics}")
    adapter_after = {agent: adapter_digest(engine, agent) for agent in engine.AGENTS}
    assert adapter_after["A"] != adapter_before["A"], "A adapter did not change"
    assert adapter_after["B"] == adapter_before["B"], "B adapter changed during A update"
    assert adapter_after["I"] == adapter_before["I"], "I adapter changed during A update"
    assert frozen_fingerprint(engine.model, exclude_adapters=True) == base_before, "Frozen base changed"
    assert frozen_fingerprint(engine.judge) == judge_before, "Frozen judge changed"
    engine.assert_judge_frozen()
    print(json.dumps({"smoke_stage": "isolated_update", "metrics": metrics}), flush=True)

    other = engine.generate("B", [short], kind="bit", seed=seed + 4)[0]
    assert other.final_text in ("0", "1")
    judge_messages = [{"role": "system", "content": (
        "Evaluate whether the answer is relevant, sensible, and clearly written. "
        "Think privately, then output PASS or FAIL.")},
        {"role": "user", "content": (
            "Question: How can I keep a paper bag dry in the rain? "
            "Answer: Put the paper bag inside a waterproof bag. Keep the opening covered as you carry it.")}]
    verdict = engine.generate("J", [judge_messages], kind="judge", seed=seed + 5)[0]
    assert verdict.final_text in ("PASS", "FAIL")
    engine.assert_judge_frozen()

    engine._activate("A", train=False)
    with torch.inference_mode():
        expected = engine._trajectory_logps(group[0]).clone()
    expected_optimizers = {agent: optimizer_digest(opt) for agent, opt in engine.optimizers.items()}
    with tempfile.TemporaryDirectory(prefix="stego-smoke-") as directory:
        engine.save(directory)
        with torch.no_grad():
            engine.adapter_parameters["A"][0].add_(0.125)
        assert adapter_digest(engine, "A") != adapter_after["A"]
        engine.load(directory)
    assert {a: adapter_digest(engine, a) for a in engine.AGENTS} == adapter_after
    assert {a: optimizer_digest(opt) for a, opt in engine.optimizers.items()} == expected_optimizers
    with torch.inference_mode():
        restored = engine._trajectory_logps(group[0])
    torch.testing.assert_close(restored, expected, atol=1e-6, rtol=1e-6)
    assert frozen_fingerprint(engine.model, exclude_adapters=True) == base_before
    assert frozen_fingerprint(engine.judge) == judge_before
    engine.assert_judge_frozen()

    return {"status": "passed", "seed": seed, "seconds": time.monotonic() - started,
            "device": torch.cuda.get_device_name(),
            "communicator_path": cfg["communicator_path"], "judge_path": cfg["judge_path"],
            "smoke_think_tokens": 32, "smoke_answer_tokens": 48,
            "production_think_tokens": config.get("think_tokens", 256),
            "decoder_objective": cfg.get('decoder_objective', 'grpo'),
            "all_wrong_decoder_group_tested": hybrid,
            "ragged_prompt_lengths": [len(t.prompt_ids) for t in ragged],
            "ragged_thought_lengths": [t.thought_token_count for t in ragged],
            "variable_thought_lengths_seen": len({t.thought_token_count for t in ragged}) > 1,
            "behavior_probability_check": consistency,
            "sender_behavior_probability_check": sender_consistency,
            "update_metrics": metrics, "selected_adapter_changed": True,
            "other_adapters_unchanged": True, "base_unchanged": True,
            "judge_unchanged": True, "checkpoint_restored_exactly": True,
            "judge_verdict": verdict.final_text,
            "peak_gpu_memory_allocated_bytes": torch.cuda.max_memory_allocated(),
            "note": ("All-wrong bit group repeats one sampled trajectory eight times with its opposite bit as target; "
                     "isolated plumbing canary only, no adapters retained." if hybrid else
                     "Synthetic rewards used only in an isolated canary process; no adapters retained.")}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    started = time.monotonic()
    try:
        report = run(json.loads(args.config.read_text()))
    except Exception as exc:
        report = {"status": "failed", "error": repr(exc), "seconds": time.monotonic() - started}
        if args.output:
            args.output.parent.mkdir(parents=True, exist_ok=True)
            args.output.write_text(json.dumps(report, indent=2) + "\n")
        print(json.dumps(report), flush=True)
        raise
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2), flush=True)


if __name__ == "__main__":
    main()
