"""PIQA adversarial communication experiment."""
